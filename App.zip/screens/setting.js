import { StyleSheet, View, Text } from "react-native";
import React from "react";

export default function Setting() {
    return (
        <View >
            <Text >Ini Setting</Text>
        </View>
    );
}